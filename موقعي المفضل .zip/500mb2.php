<?php
// طباعة الشعارات والرسائل
echo "
███████╗░█████╗░░█████╗░
██╔════╝██╔══██╗██╔══██╗
██████╗░██║░░██║██║░░██║
╚════██╗██║░░██║██║░░██║
██████╔╝╚█████╔╝╚█████╔╝
╚═════╝░░╚════╝░░╚════╝░

██╗░░░██╗███╗░░██╗██╗████████╗
██║░░░██║████╗░██║██║╚══██╔══╝
██║░░░██║██╔██╗██║██║░░░██║░░░
██║░░░██║██║╚████║██║░░░██║░░░
╚██████╔╝██║░╚███║██║░░░██║░░░
░╚═════╝░╚═╝░░╚══╝╚═╝░░░╚═╝░░░

░█████╗░██████╗░░█████╗░███╗░░██╗░██████╗░███████╗
██╔══██╗██╔══██╗██╔══██╗████╗░██║██╔════╝░██╔════╝
██║░░██║██████╔╝███████║██╔██╗██║██║░░██╗░█████╗░░
██║░░██║██╔══██╗██╔══██║██║╚████║██║░░╚██╗██╔══╝░░
╚█████╔╝██║░░██║██║░░██║██║░╚███║╚██████╔╝███████╗
░╚════╝░╚═╝░░╚═╝╚═╝░░╚═╝╚═╝░░╚══╝░╚═════╝░╚══════╝
";

echo "Welcome to My Script Orange 500 units By Aliosma\n\n";

// قراءة المدخلات
$num = readline("Enter Your Number: ");
echo "\n";
$pas = readline("Enter Your Password: ");
echo "\n";

// التحقق من صحة المدخلات
if (!preg_match("/^[0-9]+$/", $num)) {
    die("Invalid phone number. Please enter numbers only.\n");
}
if (empty($pas)) {
    die("Password cannot be empty.\n");
}

// دالة مساعدة لإرسال طلبات cURL
function sendRequest($url, $headers, $data) {
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($ch);

    if (curl_errno($ch)) {
        curl_close($ch);
        die("Error: " . curl_error($ch));
    }
    curl_close($ch);

    $decodedResponse = json_decode($response, true);
    if (json_last_error() !== JSON_ERROR_NONE) {
        die("Error decoding JSON response.");
    }

    return $decodedResponse;
}

// Step 1: Generate Token
$url_log = "https://services.orange.eg/GetToken.svc/GenerateToken";
$header_log = array(
    "Content-Type: application/json; charset=UTF-8"
);
$data_log = '{"channel":{"ChannelName":"MobinilAndMe","Password":"ig3yh*mk5l42@oj7QAR8yF"}}';

$response = sendRequest($url_log, $header_log, $data_log);
$ctv = $response["GenerateTokenResult"]["Token"] ?? null;

if (!$ctv) {
    die("Failed to generate token.");
}

// Step 2: Hash Token
$htv = strtoupper(hash('sha256', $ctv . ',{.c][o^uecnlkijh*.iomv:QzCFRcd;drof/zx}w;ls.e85T^#ASwa?=(lk'));

// Step 3: Sign In User
$url = "https://services.orange.eg/SignIn.svc/SignInUser";
$header = array(
    "_ctv: $ctv",
    "_htv: $htv",
    "net-msg-id: 8b997f69029030d17107814198191009",
    "x-microservice-name: APMS",
    "Content-Type: application/json; charset=UTF-8",
    "Content-Length: " . strlen($data),
    "Host: services.orange.eg",
    "Connection: Keep-Alive",
    "Accept-Encoding: gzip",
    "User-Agent: okhttp/3.14.9"
);
$data = '{"appVersion":"7.2.0","channel":{"ChannelName":"MobinilAndMe","Password":"ig3yh*mk5l42@oj7QAR8yF"},"dialNumber":"' . $num . '","isAndroid":"true","password":"' . $pas . '"}';

$response = sendRequest($url, $header, $data);

// Step 4: Check Available Renewal Gifts
$url2 = "https://backend.orange.eg/Internet/api/Go/AvailableRenewalGifts";
$dataG2 = '{"Channel":{"ChannelName":"MobinilAndMe","Password":"ig3yh*mk5l42@oj7QAR8yF"},"CurrentVersion":"720","Days":"0","Dial":"' . $num . '","IsEasyLogin":false,"Lang":"ar","Operation":"1","Order":"2","Password":"' . $pas . '","Promo":"go-2"}';
$headerG2 = array(
    "_ctv: $ctv",
    "_htv: $htv",
    "net-msg-id: 33fe05e6004553d17111350376071101",
    "x-microservice-name: APMS",
    "Content-Type: application/json; charset=UTF-8",
    "Content-Length: " . strlen($dataG2),
    "Host: backend.orange.eg",
    "Connection: Keep-Alive",
    "Accept-Encoding: gzip",
    "User-Agent: okhttp/3.14.9"
);

$response2 = sendRequest($url2, $headerG2, $dataG2);

if (isset($response2["ErrorDescription"])) {
    echo $response2["ErrorDescription"] . "\n";
} else {
    echo "No error description found in response.\n";
}

// By_Aliosma
?>