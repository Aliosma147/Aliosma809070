<?php
// استقبال المدخلات من النموذج إذا كان الكود يعمل في بيئة ويب
$num = $_POST['number'] ?? '';
$pas = $_POST['password'] ?? '';

// تحقق من صحة المدخلات
if (empty($num) || empty($pas)) {
    echo "\x1b[1;31mError: Number and password are required.\n";
    exit();
}

// إعداد طلب GenerateToken
$url2 = "https://services.orange.eg/GetToken.svc/GenerateToken";
$hd2 = [
    "Content-type" => "application/json",
    "Content-Length" => "78",
    "Host" => "services.orange.eg",
    "Connection" => "Keep-Alive",
    "User-Agent" => "okhttp/3.12.1"
];

$data2 = '{"appVersion":"2.9.8","channel":{"ChannelName":"MobinilAndMe","Password":"ig3yh*mk5l42@oj7QAR8yF"},"dialNumber":"' . $num . '","isAndroid":true,"password":"' . $pas . '"}';

$ch = curl_init($url2);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, $hd2);
curl_setopt($ch, CURLOPT_POSTFIELDS, $data2);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$response = curl_exec($ch);

if (curl_errno($ch)) {
    echo "\x1b[1;31mError: " . curl_error($ch) . "\n";
    curl_close($ch);
    exit();
}

curl_close($ch);

if (!$response) {
    echo "\x1b[1;31mError: Failed to get a response from the server.\n";
    exit();
}

$responseData = json_decode($response, true);
if (json_last_error() !== JSON_ERROR_NONE || !isset($responseData["GenerateTokenResult"]["Token"])) {
    echo "\x1b[1;31mError: Invalid response from the server.\n";
    exit();
}

$ctv = $responseData["GenerateTokenResult"]["Token"];
$a = $ctv . ',{.c][o^uecnlkijh*.iomv:QzCFRcd;drof/zx}w;ls.e85T^#ASwa?=(lk';
$htv = strtoupper(hash('sha256', $a));

// إعداد طلب SignInUser
$ur1 = 'https://services.orange.eg/SignIn.svc/SignInUser';
$headers = [
    'IsAndroid' => 'true',
    '_ctv' => $ctv,
    '_htv' => $htv,
    'OsVersion' => '9',
    'AppVersion' => '6.4.0',
    'Content-type' => 'application/json',
    'Accept' => 'application/json',
    'User-Agent' => 'okhttp/3.14.9',
    'Host' => 'services.orange.eg'
];

$data1 = '{"appVersion":"6.4.0","channel":{"ChannelName":"MobinilAndMe","Password":"ig3yh*mk5l42@oj7QAR8yF"},"dialNumber":"' . $num . '","isAndroid":true,"password":"' . $pas . '"}';

$ch = curl_init($ur1);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
curl_setopt($ch, CURLOPT_POSTFIELDS, $data1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$req = curl_exec($ch);

if (curl_errno($ch)) {
    echo "\x1b[1;31mError: " . curl_error($ch) . "\n";
    curl_close($ch);
    exit();
}

curl_close($ch);

if (!$req) {
    echo "\x1b[1;31mError: Failed to get a response from the server.\n";
    exit();
}

$reqData = json_decode($req, true);
if (json_last_error() !== JSON_ERROR_NONE || !isset($reqData["SignInUserResult"]["ErrorDescription"])) {
    echo "\x1b[1;31mError: Invalid response from the server.\n";
    exit();
}

$longe = $reqData["SignInUserResult"]["ErrorDescription"];
echo "\x1b[1;32m    " . $longe . "\n\x1b[1;31m";

if ($longe == 'invalid number or password ...') {
    exit();
}

// Continue with the rest of the script...
?>