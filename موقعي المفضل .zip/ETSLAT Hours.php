```php
<?php
// استخدام مكتبات خارجية
require 'vendor/autoload.php'; // تأكد من تثبيت المكتبات باستخدام Composer

use GuzzleHttp\Client;
use GuzzleHttp\Exception\RequestException;

function flag() {
    $ramadan_kareem = "❤️‍🔥2 HOURS❤️‍🔥";
    $titanic_text = "Aliosma";

    // طباعة النصوص الملونة
    echo "\033[1;33m" . str_pad($ramadan_kareem, 50, " ", STR_PAD_BOTH) . "\033[0m\n";
    echo "\033[1;31m" . str_repeat("-", 50) . "\033[0m\n";
    echo "\033[1;32m" . str_pad($titanic_text, 50, " ", STR_PAD_BOTH) . "\033[0m\n";

    // لا يمكن فتح الروابط في PHP مثل Python
    $telegram_channel_link = "https://t.me/titanic33";
    echo "Opening Telegram channel... (please visit the link in your browser)\n"; 

    echo "\033[1;31m" . str_repeat("-", 50) . "\033[0m\n";

    // قراءة المدخلات
    $number = readline("\033[1;33mEnter Your Number : \033[0m");
    $password = readline("\033[1;33mENTER Your Password : \033[0m");
    $email = readline("\033[1;33mENTER Your Email : \033[0m");

    // تحقق من المدخلات
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo "\033[1;31mالبريد الإلكتروني غير صالح.\033[0m\n";
        return;
    }

    if (!preg_match('/^[0-9]+$/', $number)) {
        echo "\033[1;31mرقم الهاتف يجب أن يحتوي على أرقام فقط.\033[0m\n";
        return;
    }

    // معالجة الرقم
    if (strpos($number, "011") === 0) {
        $num = substr($number, 3);
    } else {
        $num = $number;
    }

    // تشفير البيانات
    $code = $email . ":" . $password;
    $auth = base64_encode($code);
    $xauth = "Basic " . $auth;

    $urllog = "https://mab.etisalat.com.eg:11003/Saytar/rest/authentication/loginWithPlan";

    $client = new Client();
    $headerslog = [
        "applicationVersion" => "2",
        "applicationName" => "MAB",
        "Accept" => "text/xml",
        "Authorization" => $xauth,
        "Content-Type" => "text/xml; charset=UTF-8",
        "User-Agent" => "okhttp/5.0.0-alpha.11",
    ];

    $datalog = "<?xml version='1.0' encoding='UTF-8' standalone='yes' ?><loginRequest><deviceId></deviceId><firstLoginAttempt>true</firstLoginAttempt><modelType></modelType><osVersion></osVersion><platform>Android</platform><udid></udid></loginRequest>";

    try {
        $log = $client->post($urllog, [
            'headers' => $headerslog,
            'body' => $datalog,
        ]);

        // تحقق من حالة الاستجابة
        if ($log->getStatusCode() !== 200) {
            throw new Exception("فشل تسجيل الدخول، رمز الحالة HTTP: " . $log->getStatusCode());
        }

        $responseBody = $log->getBody();
        if (strpos($responseBody, "true") === false) {
            throw new Exception("تسجيل الدخول فشل: بيانات الاعتماد غير صحيحة");
        }

        // قراءة قيم الكوكيز والمصادقة
        $st = $log->getHeader("Set-Cookie")[0] ?? '';
        $ck = explode(";", $st)[0] ?? '';
        $br = $log->getHeader("auth")[0] ?? '';

        $url = "https://mab.etisalat.com.eg:11003/Saytar/rest/zero11/offersV3?req=<dialAndLanguageRequest><subscriberNumber>$num</subscriberNumber><language>1</language></dialAndLanguageRequest>";
        $headers = [
            'applicationVersion' => "2",
            'Content-Type' => "text/xml",
            'applicationName' => "MAB",
            'Accept' => "text/xml",
            'Language' => "ar",
            'auth' => "Bearer " . $br,
            'Cookie' => $ck,
        ];

        $response = $client->get($url, ['headers' => $headers]);

        // تحقق من حالة الاستجابة
        if ($response->getStatusCode() == 200) {
            $root = simplexml_load_string($response->getBody());
            $offer_id = null;

            foreach ($root->mabCategory as $category) {
                foreach ($category->mabProduct as $product) {
                    foreach ($product->fulfilmentParameter as $parameter) {
                        if ((string)$parameter->name == 'Offer_ID') {
                            $offer_id = (string)$parameter->value;
                            break 3; // الخروج من الثلاث حلقات
                        }
                    }
                }
            }

            if ($offer_id) {
                // إعداد الطلب لتفعيل العرض
                $urlsub = "https://mab.etisalat.com.eg:11003/Saytar/rest/zero11/submitOrder";
                $headerssub = [
                    "applicationVersion" => "2",
                    "applicationName" => "MAB",
                    "Accept" => "text/xml",
                    "Cookie" => $ck,
                    "Language" => "ar",
                    "auth" => "Bearer " . $br,
                    "Content-Type" => "text/xml; charset=UTF-8",
                ];

                $datasub = "<?xml version='1.0' encoding='UTF-8' standalone='yes' ?><submitOrderRequest><msisdn>$num</msisdn><operation>ACTIVATE</operation><parameters><parameter><name>GIFT_FULLFILMENT_PARAMETERS</name><value>Offer_ID:$offer_id;ACTIVATE:True;isRTIM:Y</value></parameter></parameters><productName>FAN_ZONE_HOURLY_BUNDLE</productName></submitOrderRequest>";

                $subs = $client->post($urlsub, [
                    'headers' => $headerssub,
                    'body' => $datasub,
                ]);

                if (strpos($subs->getBody(), "true") !== false) {
                    echo "\033[1;31m❤️‍🔥معاك دلوقتي ساعتين سوشيال❤️‍🔥\033[0m\n";
                } else {
                    echo "\033[1;31mCheck Your Data\033[0m\n";
                }
            } else {
                echo "\033[1;31mهذا العرض غير متاح حاليا ليك حاول بكره تاني\033[0m\n";
            }
        } else {
            echo "\033[1;31mهذا العرض غير متاح حاليا ليك حاول بكره تاني\033[0m\n";
        }
    } catch (RequestException $e) {
        echo "\033[1;31mRequest error: " . $e->getMessage() . "\033[0m\n";
    } catch (Exception $e) {
        echo "\033[1;31mError: " . $e->getMessage() . "\033[0m\n";
    }
}

// استدعاء الدالة
flag();
?>
```