<?php

// تلوين النصوص
$Z = "\033[1;31m"; // أحمر
$X = "\033[1;33m"; // أصفر
$F = "\033[2;32m"; // أخضر
$C = "\033[1;97m"; // أبيض
$B = "\033[2;36m"; // سمائي
$Y = "\033[1;34m"; // أزرق فاتح

echo $F . " Ali " . PHP_EOL;
echo $F . "500 Orange" . PHP_EOL;

// فتح رابط ويب
echo $B . "by code: Ali" . PHP_EOL;
echo "" . PHP_EOL;

$num = readline($B . ' Enter a Number : ' . $Y);
echo PHP_EOL;
$pas = readline($B . ' Enter a Password : ' . $Y);
echo "" . PHP_EOL;

function sendRequest($url, $headers, $data) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($ch);
    if ($response === FALSE) {
        $error = curl_error($ch);
        curl_close($ch);
        throw new Exception("Request failed: $url - $error");
    }
    curl_close($ch);
    return json_decode($response, true);
}

try {
    // التحقق من صحة الإدخال
    if (empty($num) || empty($pas)) {
        throw new Exception("الرقم وكلمة المرور مطلوبان");
    }

    $url = 'https://services.orange.eg/SignIn.svc/SignInUser';
    $header = [
        "net-msg-id: 61f91ede006159d16840827295301013",
        "x-microservice-name: APMS",
        "Content-Type: application/json; charset=UTF-8",
        "Connection: Keep-Alive",
        "Accept-Encoding: gzip",
        "User-Agent: okhttp/3.14.9",
    ];

    $data = json_encode([
        "appVersion" => "7.2.0",
        "channel" => [
            "ChannelName" => "MobinilAndMe",
            "Password" => "ig3yh*mk5l42@oj7QAR8yF"
        ],
        "dialNumber" => $num,
        "isAndroid" => true,
        "password" => $pas
    ]);

    $r = sendRequest($url, $header, $data);
    if (!isset($r["SignInUserResult"]["UserData"]["UserID"])) {
        throw new Exception("فشل في تسجيل الدخول: تحقق من الرقم وكلمة المرور");
    }
    $userid = $r["SignInUserResult"]["UserData"]["UserID"];
    echo "Wait..🤌🔥" . PHP_EOL;

    $urlo = "https://services.orange.eg/GetToken.svc/GenerateToken";
    $hdo = [
        "Content-type: application/json",
        "Host: services.orange.eg",
        "Connection: Keep-Alive",
        "User-Agent: okhttp/3.12.1"
    ];

    $datao = json_encode([
        "appVersion" => "2.9.8",
        "channel" => [
            "ChannelName" => "MobinilAndMe",
            "Password" => "ig3yh*mk5l42@oj7QAR8yF"
        ],
        "dialNumber" => $num,
        "isAndroid" => true,
        "password" => $pas
    ]);

    $responseToken = sendRequest($urlo, $hdo, $datao);
    if (!isset($responseToken["GenerateTokenResult"]["Token"])) {
        throw new Exception("فشل في توليد التوكن");
    }
    $ctv = $responseToken["GenerateTokenResult"]["Token"];

    $key = ',{.c][o^uecnlkijh*.iomv:QzCFRcd;drof/zx}w;ls.e85T^#ASwa?=(lk';
    $htv = strtoupper(hash('sha256', $ctv . $key));

    $url2 = "https://services.orange.eg/APIs/Promotions/api/CAF/Redeem";
    $data2 = json_encode([
        "Language" => "ar",
        "OSVersion" => "Android7.0",
        "PromoCode" => "رمضان كريم",
        "dial" => $num,
        "password" => $pas,
        "Channelname" => "MobinilAndMe",
        "ChannelPassword" => "ig3yh*mk5l42@oj7QAR8yF"
    ]);

    $header2 = [
        "_ctv: $ctv",
        "_htv: $htv",
        "UserId: $userid",
        "Content-Type: application/json; charset=UTF-8",
        "Connection: Keep-Alive",
        "User-Agent: okhttp/3.14.9"
    ];

    $responseRedeem = sendRequest($url2, $header2, $data2);

    if (isset($responseRedeem['ErrorDescription'])) {
        if ($responseRedeem['ErrorDescription'] == 'Success') {
            echo $F . "تم إضافة 524 ميجا بنجاح" . PHP_EOL;
        } elseif ($responseRedeem['ErrorDescription'] == 'User is redeemed before') {
            echo $X . "العرض غير متاح لك حاليا" . PHP_EOL;
        } else {
            echo $Z . "حدث خطأ، حاول مرة أخرى" . PHP_EOL;
        }
    } else {
        echo $Z . "حدث خطأ غير متوقع، حاول مرة أخرى" . PHP_EOL;
    }
} catch (Exception $e) {
    echo $Z . "حدث خطأ: " . $e->getMessage() . PHP_EOL;
}

?>